"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dumbbell, Target, Scale, Calculator, Heart, Zap, Brain, Leaf, ArrowRight } from 'lucide-react';

interface Service {
  id: string;
  title: string;
  description: string;
  shortDesc: string;
  icon: any;
  color: string;
  benefits: string[];
}

const services: Service[] = [
  {
    id: 'muscle-gain',
    title: 'Muscle Building',
    description: 'Science-based nutrition for optimal muscle growth and strength development',
    shortDesc: 'Build lean muscle mass',
    icon: Dumbbell,
    color: 'from-health-500 to-health-600',
    benefits: ['Increased protein synthesis', 'Optimal caloric surplus', 'Progressive overload support', 'Recovery optimization']
  },
  {
    id: 'fat-loss',
    title: 'Fat Loss',
    description: 'Strategic nutrition plan for sustainable fat loss while preserving muscle mass',
    shortDesc: 'Burn fat effectively',
    icon: Target,
    color: 'from-health-400 to-health-500',
    benefits: ['Metabolic enhancement', 'Appetite control', 'Energy maintenance', 'Body composition improvement']
  },
  {
    id: 'weight-gain',
    title: 'Healthy Weight Gain',
    description: 'Nutritionally dense meal plans for healthy weight increase and body development',
    shortDesc: 'Gain weight healthily',
    icon: Scale,
    color: 'from-health-600 to-health-700',
    benefits: ['Caloric density focus', 'Nutritional balance', 'Digestive comfort', 'Gradual progression']
  },
  {
    id: 'performance',
    title: 'Athletic Performance',
    description: 'Sports nutrition optimization for peak athletic performance and endurance',
    shortDesc: 'Enhance performance',
    icon: Zap,
    color: 'from-health-500 to-health-700',
    benefits: ['Energy optimization', 'Recovery acceleration', 'Endurance enhancement', 'Peak performance timing']
  }
];

const additionalServices = [
  {
    id: 'bmi-calculator',
    title: 'BMI Calculator',
    description: 'Calculate your Body Mass Index and understand your health status',
    icon: Calculator,
    color: 'from-health-300 to-health-400'
  }
];

export default function HomePage() {
  const [hoveredService, setHoveredService] = useState<string | null>(null);

  console.log("HomePage component loaded");

  const handleServiceClick = (serviceId: string) => {
    console.log("Service clicked:", serviceId);
    // Navigate to questionnaire page
    window.location.href = `/questionnaire/${serviceId}`;
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          className="absolute top-20 left-10 w-32 h-32 bg-health-200/30 rounded-full blur-xl"
          animate={{
            x: [0, 30, 0],
            y: [0, -20, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute top-40 right-20 w-24 h-24 bg-health-300/40 rounded-full blur-lg"
          animate={{
            x: [0, -25, 0],
            y: [0, 15, 0],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
        />
        <motion.div
          className="absolute bottom-32 left-1/4 w-40 h-40 bg-health-400/20 rounded-full blur-2xl"
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2
          }}
        />
      </div>

      {/* Header */}
      <header className="relative z-10 px-6 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center justify-between max-w-7xl mx-auto"
        >
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-health-500 to-health-600 rounded-2xl flex items-center justify-center">
              <Leaf className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-health-800">TanFit</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Button variant="ghost" className="text-health-700 hover:text-health-800">About</Button>
            <Button variant="ghost" className="text-health-700 hover:text-health-800">Services</Button>
            <Button variant="ghost" className="text-health-700 hover:text-health-800">Contact</Button>
          </nav>
        </motion.div>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 px-6 py-12">
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Badge variant="secondary" className="mb-4 bg-health-100 text-health-700 border-health-200">
              Science-Based Nutrition
            </Badge>
            <h2 className="text-5xl md:text-6xl font-bold text-health-800 mb-6 leading-tight">
              Transform Your Health with
              <span className="block bg-gradient-to-r from-health-500 to-health-600 bg-clip-text text-transparent">
                Personalized Nutrition
              </span>
            </h2>
            <p className="text-xl text-health-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Get scientifically-crafted diet plans based on your body composition, goals, and lifestyle. 
              Our AI-powered system considers anatomy, biology, and sports science to create your perfect nutrition roadmap.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="relative z-10 px-6 py-16">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-center mb-12"
          >
            <h3 className="text-3xl font-bold text-health-800 mb-4">Choose Your Health Journey</h3>
            <p className="text-health-600 text-lg">Select the service that aligns with your fitness goals</p>
          </motion.div>

          {/* Main Services */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              const isHovered = hoveredService === service.id;
              
              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 * index }}
                  onHoverStart={() => {
                    console.log("Hover start:", service.id);
                    setHoveredService(service.id);
                  }}
                  onHoverEnd={() => {
                    console.log("Hover end:", service.id);
                    setHoveredService(null);
                  }}
                  whileHover={{ scale: 1.05 }}
                  className="cursor-pointer"
                  onClick={() => handleServiceClick(service.id)}
                >
                  <Card className={`organic-card transition-all duration-300 h-full ${isHovered ? 'shadow-2xl border-health-300' : ''}`}>
                    <CardHeader className="pb-3">
                      <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-4 mx-auto`}>
                        <Icon className="w-7 h-7 text-white" />
                      </div>
                      <CardTitle className="text-health-800 text-center text-lg">
                        {service.title}
                      </CardTitle>
                      <CardDescription className="text-health-600 text-center">
                        {service.shortDesc}
                      </CardDescription>
                    </CardHeader>
                    
                    <motion.div
                      initial={false}
                      animate={{
                        height: isHovered ? 'auto' : 0,
                        opacity: isHovered ? 1 : 0,
                      }}
                      transition={{ duration: 0.3, ease: "easeInOut" }}
                      className="overflow-hidden"
                    >
                      <CardContent className="pt-0">
                        <p className="text-health-700 text-sm mb-4">{service.description}</p>
                        <div className="space-y-2">
                          {service.benefits.map((benefit, i) => (
                            <div key={i} className="flex items-center space-x-2">
                              <Heart className="w-3 h-3 text-health-500" />
                              <span className="text-health-600 text-xs">{benefit}</span>
                            </div>
                          ))}
                        </div>
                        <Button className="w-full mt-4 bg-gradient-to-r from-health-500 to-health-600 hover:from-health-600 hover:to-health-700 text-white">
                          Get Started <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                      </CardContent>
                    </motion.div>
                  </Card>
                </motion.div>
              );
            })}
          </div>

          {/* Additional Services Row */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex justify-center"
          >
            <div className="w-full max-w-md">
              {additionalServices.map((service) => {
                const Icon = service.icon;
                return (
                  <Card 
                    key={service.id}
                    className="organic-card cursor-pointer hover:shadow-xl transition-all duration-300"
                    onClick={() => handleServiceClick(service.id)}
                  >
                    <CardHeader className="text-center">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-3 mx-auto`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <CardTitle className="text-health-800">{service.title}</CardTitle>
                      <CardDescription className="text-health-600">
                        {service.description}
                      </CardDescription>
                    </CardHeader>
                  </Card>
                );
              })}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative z-10 px-6 py-16 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-health-400 to-health-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-health-800 mb-2">AI-Powered Analysis</h4>
              <p className="text-health-600">Advanced algorithms analyze your body composition and metabolic needs</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-health-500 to-health-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-health-800 mb-2">Science-Based</h4>
              <p className="text-health-600">Nutrition plans rooted in anatomy, biology, and sports science research</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-health-600 to-health-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-health-800 mb-2">Personalized Results</h4>
              <p className="text-health-600">Customized meal plans delivered as detailed PDF guides</p>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}