"use client";

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, ArrowRight, User, Target, Activity, Calendar, Ruler, Weight, Heart } from 'lucide-react';
import { useParams, useRouter } from 'next/navigation';
import { BasicInfoStep } from '@/components/questionnaire/BasicInfoStep';
import { GoalsStep } from '@/components/questionnaire/GoalsStep';
import { ActivityStep } from '@/components/questionnaire/ActivityStep';
import { HealthStep } from '@/components/questionnaire/HealthStep';
import { CharacterVisualization } from '@/components/questionnaire/CharacterVisualization';
import { BMICalculator } from '@/components/questionnaire/BMICalculator';

export interface UserData {
  // Basic Info
  gender: 'male' | 'female' | '';
  age: number;
  height: number;
  weight: number;
  
  // Goals
  primaryGoal: string;
  targetWeight?: number;
  timeline: string;
  experience: string;
  
  // Activity
  activityLevel: string;
  workoutFrequency: string;
  sports: string[];
  
  // Health
  medicalConditions: string[];
  allergies: string[];
  dietaryRestrictions: string[];
  sleepHours: number;
  stressLevel: string;
  waterIntake: number;
}

const steps = [
  {
    id: 'basic',
    title: 'Basic Information',
    description: 'Tell us about yourself',
    icon: User,
  },
  {
    id: 'goals',
    title: 'Your Goals',
    description: 'What do you want to achieve?',
    icon: Target,
  },
  {
    id: 'activity',
    title: 'Activity Level',
    description: 'Your exercise and sports habits',
    icon: Activity,
  },
  {
    id: 'health',
    title: 'Health Profile',
    description: 'Medical history and lifestyle',
    icon: Heart,
  },
];

export default function QuestionnairePage() {
  const params = useParams();
  const router = useRouter();
  const service = params.service as string;
  
  const [currentStep, setCurrentStep] = useState(0);
  const [userData, setUserData] = useState<UserData>({
    gender: '',
    age: 0,
    height: 0,
    weight: 0,
    primaryGoal: '',
    timeline: '',
    experience: '',
    activityLevel: '',
    workoutFrequency: '',
    sports: [],
    medicalConditions: [],
    allergies: [],
    dietaryRestrictions: [],
    sleepHours: 8,
    stressLevel: '',
    waterIntake: 2,
  });

  console.log("Questionnaire loaded for service:", service);
  console.log("Current user data:", userData);

  // Handle BMI Calculator service
  if (service === 'bmi-calculator') {
    return <BMICalculator />;
  }

  const progress = ((currentStep + 1) / steps.length) * 100;

  const handleNext = () => {
    console.log("Moving to next step from:", currentStep);
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Generate diet plan
      console.log("Generating diet plan with data:", userData);
      router.push(`/diet-plan/${service}?data=${encodeURIComponent(JSON.stringify(userData))}`);
    }
  };

  const handleBack = () => {
    console.log("Moving to previous step from:", currentStep);
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    } else {
      router.push('/');
    }
  };

  const updateUserData = (newData: Partial<UserData>) => {
    console.log("Updating user data:", newData);
    setUserData(prev => ({ ...prev, ...newData }));
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 0: // Basic Info
        return userData.gender && userData.age > 0 && userData.height > 0 && userData.weight > 0;
      case 1: // Goals
        return userData.primaryGoal && userData.timeline && userData.experience;
      case 2: // Activity
        return userData.activityLevel && userData.workoutFrequency;
      case 3: // Health
        return true; // Health step is optional
      default:
        return false;
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <BasicInfoStep 
            userData={userData} 
            updateUserData={updateUserData}
            service={service}
          />
        );
      case 1:
        return (
          <GoalsStep 
            userData={userData} 
            updateUserData={updateUserData}
            service={service}
          />
        );
      case 2:
        return (
          <ActivityStep 
            userData={userData} 
            updateUserData={updateUserData}
          />
        );
      case 3:
        return (
          <HealthStep 
            userData={userData} 
            updateUserData={updateUserData}
          />
        );
      default:
        return null;
    }
  };

  const getServiceTitle = (serviceId: string) => {
    const titles: Record<string, string> = {
      'muscle-gain': 'Muscle Building Plan',
      'fat-loss': 'Fat Loss Plan',
      'weight-gain': 'Healthy Weight Gain Plan',
      'performance': 'Athletic Performance Plan'
    };
    return titles[serviceId] || 'Nutrition Plan';
  };

  return (
    <div className="min-h-screen bg-health-50 relative overflow-hidden">
      {/* Background Animation */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          className="absolute top-10 right-10 w-64 h-64 bg-health-200/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      <div className="relative z-10 min-h-screen flex">
        {/* Left Panel - Character Visualization */}
        <div className="hidden lg:block w-1/3 p-8">
          <CharacterVisualization userData={userData} />
        </div>

        {/* Right Panel - Questionnaire */}
        <div className="flex-1 p-6 lg:p-8">
          <div className="max-w-2xl mx-auto">
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8"
            >
              <Button
                variant="ghost"
                onClick={handleBack}
                className="mb-4 text-health-600 hover:text-health-700"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                {currentStep === 0 ? 'Back to Services' : 'Previous'}
              </Button>
              
              <h1 className="text-3xl font-bold text-health-800 mb-2">
                {getServiceTitle(service)}
              </h1>
              <p className="text-health-600 mb-6">
                Help us create your personalized nutrition plan
              </p>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm text-health-600">
                  <span>Step {currentStep + 1} of {steps.length}</span>
                  <span>{Math.round(progress)}% Complete</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            </motion.div>

            {/* Step Indicator */}
            <div className="flex justify-between mb-8">
              {steps.map((step, index) => {
                const Icon = step.icon;
                const isActive = index === currentStep;
                const isCompleted = index < currentStep;
                
                return (
                  <div key={step.id} className="flex flex-col items-center flex-1">
                    <div className={`
                      w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-all duration-300
                      ${isActive ? 'bg-health-500 text-white scale-110' : 
                        isCompleted ? 'bg-health-400 text-white' : 'bg-health-200 text-health-500'}
                    `}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className={`text-xs text-center font-medium max-w-20 ${
                      isActive ? 'text-health-800' : 'text-health-600'
                    }`}>
                      {step.title}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Step Content */}
            <Card className="organic-card mb-8">
              <CardHeader>
                <CardTitle className="text-health-800 flex items-center space-x-2">
                  {React.createElement(steps[currentStep].icon, { className: "w-6 h-6" })}
                  <span>{steps[currentStep].title}</span>
                </CardTitle>
                <p className="text-health-600">{steps[currentStep].description}</p>
              </CardHeader>
              <CardContent>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentStep}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    {renderStepContent()}
                  </motion.div>
                </AnimatePresence>
              </CardContent>
            </Card>

            {/* Navigation */}
            <div className="flex justify-between">
              <Button
                variant="outline"
                onClick={handleBack}
                className="border-health-300 text-health-600 hover:bg-health-50"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                {currentStep === 0 ? 'Back to Services' : 'Previous'}
              </Button>
              
              <Button
                onClick={handleNext}
                disabled={!isStepValid()}
                className="bg-gradient-to-r from-health-500 to-health-600 hover:from-health-600 hover:to-health-700 text-white"
              >
                {currentStep === steps.length - 1 ? 'Generate Diet Plan' : 'Next'}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}