"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Calculator, Ruler, Weight, TrendingUp, AlertCircle } from 'lucide-react';
import { useRouter } from 'next/navigation';

export function BMICalculator() {
  const router = useRouter();
  const [gender, setGender] = useState<'male' | 'female' | ''>('');
  const [age, setAge] = useState<number>(0);
  const [height, setHeight] = useState<number>(0);
  const [weight, setWeight] = useState<number>(0);
  const [result, setResult] = useState<{
    bmi: number;
    category: string;
    description: string;
    color: string;
    recommendations: string[];
  } | null>(null);

  console.log("BMI Calculator loaded");

  const calculateBMI = () => {
    if (height <= 0 || weight <= 0) return;

    const bmi = weight / Math.pow(height / 100, 2);
    let category = '';
    let description = '';
    let color = '';
    let recommendations: string[] = [];

    if (bmi < 18.5) {
      category = 'Underweight';
      description = 'You are below the normal weight range';
      color = 'text-blue-600 bg-blue-50 border-blue-200';
      recommendations = [
        'Consider increasing caloric intake with nutrient-dense foods',
        'Focus on healthy weight gain through muscle building',
        'Consult with a healthcare provider about gaining weight safely',
        'Include protein-rich foods and healthy fats in your diet'
      ];
    } else if (bmi < 25) {
      category = 'Normal Weight';
      description = 'You are within the normal weight range';
      color = 'text-health-600 bg-health-50 border-health-200';
      recommendations = [
        'Maintain your current weight with a balanced diet',
        'Continue regular physical activity',
        'Focus on overall health and fitness rather than weight loss',
        'Ensure adequate nutrition to support your lifestyle'
      ];
    } else if (bmi < 30) {
      category = 'Overweight';
      description = 'You are above the normal weight range';
      color = 'text-yellow-600 bg-yellow-50 border-yellow-200';
      recommendations = [
        'Consider moderate weight loss through diet and exercise',
        'Focus on creating a sustainable caloric deficit',
        'Increase physical activity and reduce sedentary time',
        'Consult with a healthcare provider for a weight loss plan'
      ];
    } else {
      category = 'Obese';
      description = 'You are significantly above the normal weight range';
      color = 'text-red-600 bg-red-50 border-red-200';
      recommendations = [
        'Consider significant lifestyle changes for weight loss',
        'Consult with a healthcare provider immediately',
        'Focus on gradual, sustainable weight loss',
        'Consider professional nutritional and medical guidance'
      ];
    }

    const calculatedResult = {
      bmi: parseFloat(bmi.toFixed(1)),
      category,
      description,
      color,
      recommendations
    };

    console.log("BMI calculated:", calculatedResult);
    setResult(calculatedResult);
  };

  const resetCalculator = () => {
    console.log("Resetting BMI calculator");
    setGender('');
    setAge(0);
    setHeight(0);
    setWeight(0);
    setResult(null);
  };

  const isValid = height > 0 && weight > 0 && age > 0 && gender;

  return (
    <div className="min-h-screen bg-health-50 relative overflow-hidden">
      {/* Background Animation */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          className="absolute top-20 right-20 w-64 h-64 bg-health-200/20 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      <div className="relative z-10 min-h-screen p-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <Button
              variant="ghost"
              onClick={() => router.push('/')}
              className="mb-4 text-health-600 hover:text-health-700"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Services
            </Button>
            
            <h1 className="text-4xl font-bold text-health-800 mb-4 flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-health-500 to-health-600 rounded-2xl flex items-center justify-center">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <span>BMI Calculator</span>
            </h1>
            <p className="text-health-600 text-lg">
              Calculate your Body Mass Index and get personalized health recommendations
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Calculator Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="organic-card">
                <CardHeader>
                  <CardTitle className="text-health-800">Enter Your Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Gender */}
                  <div className="space-y-3">
                    <Label className="text-health-700 font-medium">Gender</Label>
                    <RadioGroup
                      value={gender}
                      onValueChange={(value) => setGender(value as 'male' | 'female' | '')}
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="male" id="male" />
                        <Label htmlFor="male" className="cursor-pointer">Male</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="female" id="female" />
                        <Label htmlFor="female" className="cursor-pointer">Female</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Age */}
                  <div className="space-y-3">
                    <Label htmlFor="age" className="text-health-700 font-medium">Age (years)</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter your age"
                      value={age || ''}
                      onChange={(e) => setAge(parseInt(e.target.value) || 0)}
                      className="border-health-300 focus:border-health-500 focus:ring-health-500"
                      min="1"
                      max="120"
                    />
                  </div>

                  {/* Height */}
                  <div className="space-y-3">
                    <Label htmlFor="height" className="text-health-700 font-medium flex items-center space-x-2">
                      <Ruler className="w-4 h-4" />
                      <span>Height (cm)</span>
                    </Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="Enter your height in centimeters"
                      value={height || ''}
                      onChange={(e) => setHeight(parseFloat(e.target.value) || 0)}
                      className="border-health-300 focus:border-health-500 focus:ring-health-500"
                      min="50"
                      max="300"
                      step="0.1"
                    />
                    <p className="text-xs text-health-600">Example: 175 cm = 5'9"</p>
                  </div>

                  {/* Weight */}
                  <div className="space-y-3">
                    <Label htmlFor="weight" className="text-health-700 font-medium flex items-center space-x-2">
                      <Weight className="w-4 h-4" />
                      <span>Weight (kg)</span>
                    </Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder="Enter your weight in kilograms"
                      value={weight || ''}
                      onChange={(e) => setWeight(parseFloat(e.target.value) || 0)}
                      className="border-health-300 focus:border-health-500 focus:ring-health-500"
                      min="20"
                      max="500"
                      step="0.1"
                    />
                    <p className="text-xs text-health-600">Example: 70 kg = 154 lbs</p>
                  </div>

                  {/* Calculate Button */}
                  <div className="flex space-x-3">
                    <Button
                      onClick={calculateBMI}
                      disabled={!isValid}
                      className="flex-1 bg-gradient-to-r from-health-500 to-health-600 hover:from-health-600 hover:to-health-700 text-white"
                    >
                      <Calculator className="w-4 h-4 mr-2" />
                      Calculate BMI
                    </Button>
                    {result && (
                      <Button
                        variant="outline"
                        onClick={resetCalculator}
                        className="border-health-300 text-health-600 hover:bg-health-50"
                      >
                        Reset
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Results */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              {result ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className={`organic-card border-2 ${result.color}`}>
                    <CardHeader>
                      <CardTitle className="text-health-800 flex items-center space-x-2">
                        <TrendingUp className="w-5 h-5" />
                        <span>Your BMI Result</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* BMI Value */}
                      <div className="text-center">
                        <div className="text-6xl font-bold text-health-800 mb-2">
                          {result.bmi}
                        </div>
                        <Badge className={`text-lg px-4 py-2 ${result.color}`}>
                          {result.category}
                        </Badge>
                        <p className="text-health-600 mt-2">{result.description}</p>
                      </div>

                      <Separator />

                      {/* BMI Scale Visual */}
                      <div className="space-y-2">
                        <h4 className="font-medium text-health-800">BMI Scale</h4>
                        <div className="grid grid-cols-4 gap-1 text-xs">
                          <div className={`p-2 rounded text-center ${result.bmi < 18.5 ? 'bg-blue-500 text-white' : 'bg-blue-100 text-blue-700'}`}>
                            &lt;18.5<br/>Under
                          </div>
                          <div className={`p-2 rounded text-center ${result.bmi >= 18.5 && result.bmi < 25 ? 'bg-health-500 text-white' : 'bg-health-100 text-health-700'}`}>
                            18.5-24.9<br/>Normal
                          </div>
                          <div className={`p-2 rounded text-center ${result.bmi >= 25 && result.bmi < 30 ? 'bg-yellow-500 text-white' : 'bg-yellow-100 text-yellow-700'}`}>
                            25-29.9<br/>Over
                          </div>
                          <div className={`p-2 rounded text-center ${result.bmi >= 30 ? 'bg-red-500 text-white' : 'bg-red-100 text-red-700'}`}>
                            ≥30<br/>Obese
                          </div>
                        </div>
                      </div>

                      <Separator />

                      {/* Recommendations */}
                      <div className="space-y-3">
                        <h4 className="font-medium text-health-800 flex items-center space-x-2">
                          <AlertCircle className="w-4 h-4" />
                          <span>Recommendations</span>
                        </h4>
                        <ul className="space-y-2">
                          {result.recommendations.map((rec, index) => (
                            <motion.li
                              key={index}
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: 0.1 * index }}
                              className="flex items-start space-x-2 text-sm text-health-700"
                            >
                              <span className="text-health-500 mt-0.5">•</span>
                              <span>{rec}</span>
                            </motion.li>
                          ))}
                        </ul>
                      </div>

                      {/* Get Personalized Plan CTA */}
                      <div className="space-y-3">
                        <Separator />
                        <div className="text-center space-y-3">
                          <h4 className="font-medium text-health-800">Want a Personalized Nutrition Plan?</h4>
                          <p className="text-sm text-health-600">
                            Get a science-based diet plan tailored to your goals and body composition
                          </p>
                          <Button
                            onClick={() => router.push('/')}
                            className="w-full bg-gradient-to-r from-health-500 to-health-600 hover:from-health-600 hover:to-health-700 text-white"
                          >
                            Explore Nutrition Services
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ) : (
                <Card className="organic-card">
                  <CardContent className="p-8 text-center">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                      className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-health-300 to-health-500 flex items-center justify-center"
                    >
                      <Calculator className="w-8 h-8 text-white" />
                    </motion.div>
                    <h3 className="text-lg font-medium text-health-800 mb-2">Ready to Calculate</h3>
                    <p className="text-health-600">
                      Fill in your information on the left to calculate your BMI and get personalized recommendations.
                    </p>
                  </CardContent>
                </Card>
              )}
            </motion.div>
          </div>

          {/* BMI Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-8"
          >
            <Card className="organic-card">
              <CardContent className="p-6">
                <h3 className="font-medium text-health-800 mb-3">About BMI</h3>
                <p className="text-sm text-health-600 leading-relaxed">
                  Body Mass Index (BMI) is a measure of body fat based on height and weight. While BMI is a useful screening tool, 
                  it doesn't directly measure body fat and may not accurately reflect health status for athletes, elderly, or individuals 
                  with high muscle mass. For the most accurate health assessment, consult with a healthcare professional who can consider 
                  additional factors like body composition, muscle mass, and overall health indicators.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}