"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Heart, Shield, Droplets, Moon, Zap, X, Plus } from 'lucide-react';
import { UserData } from '@/app/questionnaire/[service]/page';

interface HealthStepProps {
  userData: UserData;
  updateUserData: (data: Partial<UserData>) => void;
}

const medicalConditions = [
  'Diabetes Type 1', 'Diabetes Type 2', 'High Blood Pressure', 'High Cholesterol',
  'Heart Disease', 'Thyroid Issues', 'PCOS', 'Celiac Disease',
  'Crohn\'s Disease', 'IBS', 'Kidney Disease', 'Liver Disease',
  'Metabolic Syndrome', 'Insulin Resistance', 'Food Intolerances'
];

const commonAllergies = [
  'Nuts', 'Peanuts', 'Shellfish', 'Fish', 'Eggs', 'Dairy', 'Soy', 'Wheat/Gluten',
  'Sesame', 'Sulfites', 'Food Dyes', 'Preservatives'
];

const dietaryRestrictions = [
  'Vegetarian', 'Vegan', 'Pescatarian', 'Keto', 'Paleo', 'Mediterranean',
  'Low Carb', 'Low Fat', 'Gluten-Free', 'Dairy-Free', 'Intermittent Fasting',
  'Halal', 'Kosher', 'Raw Food', 'DASH Diet'
];

const stressLevels = [
  { value: 'very-low', label: 'Very Low', description: 'Rarely stressed', icon: '😌' },
  { value: 'low', label: 'Low', description: 'Occasionally stressed', icon: '🙂' },
  { value: 'moderate', label: 'Moderate', description: 'Sometimes stressed', icon: '😐' },
  { value: 'high', label: 'High', description: 'Often stressed', icon: '😰' },
  { value: 'very-high', label: 'Very High', description: 'Constantly stressed', icon: '😫' }
];

export function HealthStep({ userData, updateUserData }: HealthStepProps) {
  const [customCondition, setCustomCondition] = useState('');
  const [customAllergy, setCustomAllergy] = useState('');
  const [customRestriction, setCustomRestriction] = useState('');

  console.log("HealthStep rendered with userData:", userData);

  const handleConditionToggle = (condition: string, checked: boolean) => {
    console.log("Medical condition toggle:", condition, checked);
    const newConditions = checked
      ? [...userData.medicalConditions, condition]
      : userData.medicalConditions.filter(c => c !== condition);
    updateUserData({ medicalConditions: newConditions });
  };

  const handleAllergyToggle = (allergy: string, checked: boolean) => {
    console.log("Allergy toggle:", allergy, checked);
    const newAllergies = checked
      ? [...userData.allergies, allergy]
      : userData.allergies.filter(a => a !== allergy);
    updateUserData({ allergies: newAllergies });
  };

  const handleRestrictionToggle = (restriction: string, checked: boolean) => {
    console.log("Dietary restriction toggle:", restriction, checked);
    const newRestrictions = checked
      ? [...userData.dietaryRestrictions, restriction]
      : userData.dietaryRestrictions.filter(r => r !== restriction);
    updateUserData({ dietaryRestrictions: newRestrictions });
  };

  const addCustomItem = (item: string, type: 'condition' | 'allergy' | 'restriction') => {
    if (!item.trim()) return;
    
    console.log("Adding custom item:", item, type);
    switch (type) {
      case 'condition':
        if (!userData.medicalConditions.includes(item)) {
          updateUserData({ medicalConditions: [...userData.medicalConditions, item] });
        }
        setCustomCondition('');
        break;
      case 'allergy':
        if (!userData.allergies.includes(item)) {
          updateUserData({ allergies: [...userData.allergies, item] });
        }
        setCustomAllergy('');
        break;
      case 'restriction':
        if (!userData.dietaryRestrictions.includes(item)) {
          updateUserData({ dietaryRestrictions: [...userData.dietaryRestrictions, item] });
        }
        setCustomRestriction('');
        break;
    }
  };

  const removeCustomItem = (item: string, type: 'condition' | 'allergy' | 'restriction') => {
    console.log("Removing item:", item, type);
    switch (type) {
      case 'condition':
        updateUserData({ medicalConditions: userData.medicalConditions.filter(c => c !== item) });
        break;
      case 'allergy':
        updateUserData({ allergies: userData.allergies.filter(a => a !== item) });
        break;
      case 'restriction':
        updateUserData({ dietaryRestrictions: userData.dietaryRestrictions.filter(r => r !== item) });
        break;
    }
  };

  return (
    <div className="space-y-6">
      {/* Medical Conditions */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium flex items-center space-x-2">
          <Shield className="w-4 h-4" />
          <span>Do you have any medical conditions?</span>
        </Label>
        <p className="text-sm text-health-600">Select any that apply to ensure your nutrition plan is safe and effective.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {medicalConditions.map((condition) => (
            <div key={condition} className="flex items-center space-x-2 p-2 rounded-lg hover:bg-health-50">
              <Checkbox
                id={condition}
                checked={userData.medicalConditions.includes(condition)}
                onCheckedChange={(checked) => handleConditionToggle(condition, checked as boolean)}
              />
              <Label htmlFor={condition} className="text-sm cursor-pointer flex-1">
                {condition}
              </Label>
            </div>
          ))}
        </div>

        {/* Custom Medical Condition */}
        <div className="flex space-x-2">
          <Input
            placeholder="Add other medical condition..."
            value={customCondition}
            onChange={(e) => setCustomCondition(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addCustomItem(customCondition, 'condition')}
            className="text-sm"
          />
          <button
            onClick={() => addCustomItem(customCondition, 'condition')}
            disabled={!customCondition.trim()}
            className="px-3 py-2 bg-health-500 text-white rounded-md hover:bg-health-600 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Selected Custom Conditions */}
        {userData.medicalConditions.filter(c => !medicalConditions.includes(c)).length > 0 && (
          <div className="flex flex-wrap gap-2">
            {userData.medicalConditions.filter(c => !medicalConditions.includes(c)).map((condition) => (
              <Badge key={condition} variant="outline" className="pr-1">
                {condition}
                <button
                  onClick={() => removeCustomItem(condition, 'condition')}
                  className="ml-1 hover:bg-health-100 rounded-full p-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </div>

      {/* Allergies */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium flex items-center space-x-2">
          <Heart className="w-4 h-4" />
          <span>Do you have any food allergies?</span>
        </Label>
        
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {commonAllergies.map((allergy) => (
            <div key={allergy} className="flex items-center space-x-2 p-2 rounded-lg hover:bg-health-50">
              <Checkbox
                id={allergy}
                checked={userData.allergies.includes(allergy)}
                onCheckedChange={(checked) => handleAllergyToggle(allergy, checked as boolean)}
              />
              <Label htmlFor={allergy} className="text-sm cursor-pointer flex-1">
                {allergy}
              </Label>
            </div>
          ))}
        </div>

        {/* Custom Allergy */}
        <div className="flex space-x-2">
          <Input
            placeholder="Add other allergy..."
            value={customAllergy}
            onChange={(e) => setCustomAllergy(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addCustomItem(customAllergy, 'allergy')}
            className="text-sm"
          />
          <button
            onClick={() => addCustomItem(customAllergy, 'allergy')}
            disabled={!customAllergy.trim()}
            className="px-3 py-2 bg-health-500 text-white rounded-md hover:bg-health-600 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Dietary Restrictions */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium">Do you follow any specific diet?</Label>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {dietaryRestrictions.map((restriction) => (
            <div key={restriction} className="flex items-center space-x-2 p-2 rounded-lg hover:bg-health-50">
              <Checkbox
                id={restriction}
                checked={userData.dietaryRestrictions.includes(restriction)}
                onCheckedChange={(checked) => handleRestrictionToggle(restriction, checked as boolean)}
              />
              <Label htmlFor={restriction} className="text-sm cursor-pointer flex-1">
                {restriction}
              </Label>
            </div>
          ))}
        </div>

        {/* Custom Dietary Restriction */}
        <div className="flex space-x-2">
          <Input
            placeholder="Add other dietary preference..."
            value={customRestriction}
            onChange={(e) => setCustomRestriction(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addCustomItem(customRestriction, 'restriction')}
            className="text-sm"
          />
          <button
            onClick={() => addCustomItem(customRestriction, 'restriction')}
            disabled={!customRestriction.trim()}
            className="px-3 py-2 bg-health-500 text-white rounded-md hover:bg-health-600 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Sleep Hours */}
      <div className="space-y-3">
        <Label htmlFor="sleep" className="text-health-700 font-medium flex items-center space-x-2">
          <Moon className="w-4 h-4" />
          <span>How many hours do you sleep per night?</span>
        </Label>
        <Select 
          value={userData.sleepHours.toString()} 
          onValueChange={(value) => updateUserData({ sleepHours: parseInt(value) })}
        >
          <SelectTrigger className="border-health-300 focus:border-health-500 focus:ring-health-500">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {[4, 5, 6, 7, 8, 9, 10, 11, 12].map((hours) => (
              <SelectItem key={hours} value={hours.toString()}>
                {hours} hours {hours === 7 || hours === 8 ? '(Recommended)' : ''}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Stress Level */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium flex items-center space-x-2">
          <Zap className="w-4 h-4" />
          <span>What's your stress level?</span>
        </Label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          {stressLevels.map((level) => (
            <Card
              key={level.value}
              className={`cursor-pointer transition-all duration-200 ${
                userData.stressLevel === level.value ? 'ring-2 ring-health-400 bg-health-50' : 'hover:shadow-md'
              }`}
              onClick={() => updateUserData({ stressLevel: level.value })}
            >
              <CardContent className="p-3 text-center">
                <div className="text-2xl mb-1">{level.icon}</div>
                <div className="font-medium text-health-800 text-sm">{level.label}</div>
                <div className="text-xs text-health-600">{level.description}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Water Intake */}
      <div className="space-y-3">
        <Label htmlFor="water" className="text-health-700 font-medium flex items-center space-x-2">
          <Droplets className="w-4 h-4" />
          <span>How many liters of water do you drink daily?</span>
        </Label>
        <Select 
          value={userData.waterIntake.toString()} 
          onValueChange={(value) => updateUserData({ waterIntake: parseFloat(value) })}
        >
          <SelectTrigger className="border-health-300 focus:border-health-500 focus:ring-health-500">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {[0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5].map((liters) => (
              <SelectItem key={liters} value={liters.toString()}>
                {liters} L {liters >= 2 && liters <= 3 ? '(Recommended)' : ''}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Health Summary */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 bg-health-100 rounded-lg"
      >
        <h4 className="font-medium text-health-800 mb-2">Health Profile Summary</h4>
        <div className="text-sm text-health-700 space-y-1">
          <div>Sleep: <span className="font-medium">{userData.sleepHours} hours/night</span></div>
          <div>Water: <span className="font-medium">{userData.waterIntake}L/day</span></div>
          {userData.stressLevel && (
            <div>Stress: <span className="font-medium">{stressLevels.find(s => s.value === userData.stressLevel)?.label}</span></div>
          )}
          {userData.medicalConditions.length > 0 && (
            <div>Conditions: <span className="font-medium">{userData.medicalConditions.length} noted</span></div>
          )}
          {userData.allergies.length > 0 && (
            <div>Allergies: <span className="font-medium">{userData.allergies.length} noted</span></div>
          )}
          {userData.dietaryRestrictions.length > 0 && (
            <div>Diet: <span className="font-medium">{userData.dietaryRestrictions.join(', ')}</span></div>
          )}
        </div>
      </motion.div>

      {/* Health Tips */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="p-4 bg-blue-50 rounded-lg border border-blue-200"
      >
        <h4 className="font-medium text-blue-800 mb-2">🏥 Health & Nutrition</h4>
        <p className="text-sm text-blue-700">
          Your health profile helps us ensure your nutrition plan is safe and effective. We'll account for any medical conditions, allergies, and lifestyle factors to create the best plan for you.
        </p>
      </motion.div>
    </div>
  );
}