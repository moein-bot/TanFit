"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Activity, Calendar, Search, X } from 'lucide-react';
import { UserData } from '@/app/questionnaire/[service]/page';

interface ActivityStepProps {
  userData: UserData;
  updateUserData: (data: Partial<UserData>) => void;
}

const activityLevels = [
  { 
    value: 'sedentary', 
    label: 'Sedentary', 
    description: 'Little to no exercise',
    multiplier: '1.2x',
    icon: '🏠'
  },
  { 
    value: 'lightly-active', 
    label: 'Lightly Active', 
    description: 'Light exercise 1-3 days/week',
    multiplier: '1.375x',
    icon: '🚶'
  },
  { 
    value: 'moderately-active', 
    label: 'Moderately Active', 
    description: 'Moderate exercise 3-5 days/week',
    multiplier: '1.55x',
    icon: '🏃'
  },
  { 
    value: 'very-active', 
    label: 'Very Active', 
    description: 'Hard exercise 6-7 days/week',
    multiplier: '1.725x',
    icon: '💪'
  },
  { 
    value: 'extremely-active', 
    label: 'Extremely Active', 
    description: 'Very hard exercise, physical job',
    multiplier: '1.9x',
    icon: '🏋️'
  }
];

const workoutFrequencies = [
  { value: '0', label: 'Never', description: 'I don\'t work out' },
  { value: '1-2', label: '1-2 times/week', description: 'Light activity' },
  { value: '3-4', label: '3-4 times/week', description: 'Regular exercise' },
  { value: '5-6', label: '5-6 times/week', description: 'Very active' },
  { value: '7+', label: 'Daily or more', description: 'Extremely active' }
];

const sportsDatabase = [
  'Running', 'Cycling', 'Swimming', 'Weight Training', 'Yoga', 'Pilates',
  'Basketball', 'Soccer', 'Tennis', 'Badminton', 'Volleyball', 'Baseball',
  'Boxing', 'Martial Arts', 'Rock Climbing', 'Hiking', 'Dancing', 'CrossFit',
  'Gymnastics', 'Track and Field', 'Golf', 'Skiing', 'Snowboarding', 'Surfing',
  'Rowing', 'Kayaking', 'Football', 'Rugby', 'Hockey', 'Wrestling',
  'Triathlon', 'Bodybuilding', 'Powerlifting', 'Calisthenics', 'Stretching',
  'Zumba', 'Spin Class', 'Aerobics', 'Water Aerobics', 'Tai Chi'
];

export function ActivityStep({ userData, updateUserData }: ActivityStepProps) {
  const [sportSearch, setSportSearch] = useState('');
  const [showSportSearch, setShowSportSearch] = useState(false);

  console.log("ActivityStep rendered with userData:", userData);

  const handleActivityLevelChange = (value: string) => {
    console.log("Activity level changed to:", value);
    updateUserData({ activityLevel: value });
  };

  const handleWorkoutFrequencyChange = (value: string) => {
    console.log("Workout frequency changed to:", value);
    updateUserData({ workoutFrequency: value });
  };

  const handleSportAdd = (sport: string) => {
    console.log("Adding sport:", sport);
    if (!userData.sports.includes(sport)) {
      const newSports = [...userData.sports, sport];
      updateUserData({ sports: newSports });
    }
    setSportSearch('');
    setShowSportSearch(false);
  };

  const handleSportRemove = (sport: string) => {
    console.log("Removing sport:", sport);
    const newSports = userData.sports.filter(s => s !== sport);
    updateUserData({ sports: newSports });
  };

  const filteredSports = sportsDatabase.filter(sport =>
    sport.toLowerCase().includes(sportSearch.toLowerCase()) &&
    !userData.sports.includes(sport)
  );

  return (
    <div className="space-y-6">
      {/* Activity Level */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium flex items-center space-x-2">
          <Activity className="w-4 h-4" />
          <span>What's your overall activity level?</span>
        </Label>
        <RadioGroup
          value={userData.activityLevel}
          onValueChange={handleActivityLevelChange}
          className="space-y-3"
        >
          {activityLevels.map((level) => (
            <motion.div
              key={level.value}
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
            >
              <Card className={`cursor-pointer transition-all duration-200 ${
                userData.activityLevel === level.value ? 'ring-2 ring-health-400 bg-health-50' : 'hover:shadow-md'
              }`}>
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <RadioGroupItem value={level.value} id={level.value} className="mt-1" />
                    <Label htmlFor={level.value} className="cursor-pointer flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-xl">{level.icon}</span>
                          <span className="font-medium text-health-800">{level.label}</span>
                        </div>
                        <Badge variant="secondary" className="bg-health-100 text-health-700">
                          {level.multiplier}
                        </Badge>
                      </div>
                      <div className="text-sm text-health-600">{level.description}</div>
                    </Label>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </RadioGroup>
      </div>

      {/* Workout Frequency */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium flex items-center space-x-2">
          <Calendar className="w-4 h-4" />
          <span>How often do you work out?</span>
        </Label>
        <Select value={userData.workoutFrequency} onValueChange={handleWorkoutFrequencyChange}>
          <SelectTrigger className="border-health-300 focus:border-health-500 focus:ring-health-500">
            <SelectValue placeholder="Select workout frequency" />
          </SelectTrigger>
          <SelectContent>
            {workoutFrequencies.map((freq) => (
              <SelectItem key={freq.value} value={freq.value}>
                <div className="flex flex-col">
                  <span className="font-medium">{freq.label}</span>
                  <span className="text-xs text-health-600">{freq.description}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Sports & Activities */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium">What sports or activities do you do?</Label>
        
        {/* Selected Sports */}
        {userData.sports.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {userData.sports.map((sport) => (
              <motion.div
                key={sport}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
              >
                <Badge 
                  variant="default" 
                  className="bg-health-500 text-white pr-1 flex items-center space-x-1"
                >
                  <span>{sport}</span>
                  <button
                    onClick={() => handleSportRemove(sport)}
                    className="ml-1 hover:bg-health-600 rounded-full p-0.5"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              </motion.div>
            ))}
          </div>
        )}

        {/* Add Sport Button */}
        {!showSportSearch ? (
          <button
            onClick={() => setShowSportSearch(true)}
            className="w-full p-3 border-2 border-dashed border-health-300 rounded-lg text-health-600 hover:border-health-400 hover:text-health-700 transition-colors"
          >
            <Search className="w-4 h-4 inline mr-2" />
            Add sports or activities
          </button>
        ) : (
          <div className="space-y-2">
            <div className="relative">
              <Input
                placeholder="Search for sports or activities..."
                value={sportSearch}
                onChange={(e) => setSportSearch(e.target.value)}
                className="border-health-300 focus:border-health-500 focus:ring-health-500"
                autoFocus
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-health-400" />
            </div>
            
            {sportSearch && (
              <div className="max-h-40 overflow-y-auto border border-health-200 rounded-lg bg-white">
                {filteredSports.length > 0 ? (
                  filteredSports.slice(0, 8).map((sport) => (
                    <button
                      key={sport}
                      onClick={() => handleSportAdd(sport)}
                      className="w-full text-left p-3 hover:bg-health-50 border-b border-health-100 last:border-b-0"
                    >
                      {sport}
                    </button>
                  ))
                ) : (
                  <div className="p-3 text-health-600 text-center">
                    No sports found. Try a different search term.
                  </div>
                )}
              </div>
            )}
            
            <div className="flex space-x-2">
              <button
                onClick={() => {
                  setShowSportSearch(false);
                  setSportSearch('');
                }}
                className="px-3 py-1 text-sm text-health-600 hover:text-health-700"
              >
                Cancel
              </button>
              {sportSearch && !sportsDatabase.includes(sportSearch) && (
                <button
                  onClick={() => handleSportAdd(sportSearch)}
                  className="px-3 py-1 text-sm bg-health-500 text-white rounded hover:bg-health-600"
                >
                  Add "{sportSearch}"
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Activity Summary */}
      {userData.activityLevel && userData.workoutFrequency && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-health-100 rounded-lg"
        >
          <h4 className="font-medium text-health-800 mb-2">Your Activity Profile</h4>
          <div className="text-sm text-health-700 space-y-1">
            <div>Activity Level: <span className="font-medium">{activityLevels.find(a => a.value === userData.activityLevel)?.label}</span></div>
            <div>Workout Frequency: <span className="font-medium">{workoutFrequencies.find(w => w.value === userData.workoutFrequency)?.label}</span></div>
            {userData.sports.length > 0 && (
              <div>Sports: <span className="font-medium">{userData.sports.join(', ')}</span></div>
            )}
          </div>
        </motion.div>
      )}

      {/* Tips */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="p-4 bg-blue-50 rounded-lg border border-blue-200"
      >
        <h4 className="font-medium text-blue-800 mb-2">💡 Activity Nutrition Tips</h4>
        <p className="text-sm text-blue-700">
          Your activity level directly affects your caloric needs. More active individuals require more calories and specific nutrient timing for optimal performance and recovery.
        </p>
      </motion.div>
    </div>
  );
}