"use client";

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent } from '@/components/ui/card';
import { User, Ruler, Weight } from 'lucide-react';
import { UserData } from '@/app/questionnaire/[service]/page';

interface BasicInfoStepProps {
  userData: UserData;
  updateUserData: (data: Partial<UserData>) => void;
  service: string;
}

export function BasicInfoStep({ userData, updateUserData, service }: BasicInfoStepProps) {
  console.log("BasicInfoStep rendered with userData:", userData);

  const handleGenderChange = (value: string) => {
    console.log("Gender changed to:", value);
    updateUserData({ gender: value as 'male' | 'female' });
  };

  const handleAgeChange = (value: string) => {
    const age = parseInt(value) || 0;
    console.log("Age changed to:", age);
    updateUserData({ age });
  };

  const handleHeightChange = (value: string) => {
    const height = parseFloat(value) || 0;
    console.log("Height changed to:", height);
    updateUserData({ height });
  };

  const handleWeightChange = (value: string) => {
    const weight = parseFloat(value) || 0;
    console.log("Weight changed to:", weight);
    updateUserData({ weight });
  };

  return (
    <div className="space-y-6">
      {/* Gender Selection */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium">Gender</Label>
        <RadioGroup
          value={userData.gender}
          onValueChange={handleGenderChange}
          className="flex space-x-4"
        >
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Card className={`cursor-pointer transition-all duration-200 ${
              userData.gender === 'male' ? 'ring-2 ring-health-400 bg-health-50' : 'hover:shadow-md'
            }`}>
              <CardContent className="flex items-center space-x-3 p-4">
                <RadioGroupItem value="male" id="male" />
                <Label htmlFor="male" className="cursor-pointer flex items-center space-x-2">
                  <User className="w-4 h-4" />
                  <span>Male</span>
                </Label>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Card className={`cursor-pointer transition-all duration-200 ${
              userData.gender === 'female' ? 'ring-2 ring-health-400 bg-health-50' : 'hover:shadow-md'
            }`}>
              <CardContent className="flex items-center space-x-3 p-4">
                <RadioGroupItem value="female" id="female" />
                <Label htmlFor="female" className="cursor-pointer flex items-center space-x-2">
                  <User className="w-4 h-4" />
                  <span>Female</span>
                </Label>
              </CardContent>
            </Card>
          </motion.div>
        </RadioGroup>
      </div>

      {/* Age Input */}
      <div className="space-y-3">
        <Label htmlFor="age" className="text-health-700 font-medium">Age (years)</Label>
        <div className="relative">
          <Input
            id="age"
            type="number"
            placeholder="Enter your age"
            value={userData.age || ''}
            onChange={(e) => handleAgeChange(e.target.value)}
            className="pl-10 border-health-300 focus:border-health-500 focus:ring-health-500"
            min="1"
            max="120"
          />
          <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-health-500" />
        </div>
      </div>

      {/* Height Input */}
      <div className="space-y-3">
        <Label htmlFor="height" className="text-health-700 font-medium">Height (cm)</Label>
        <div className="relative">
          <Input
            id="height"
            type="number"
            placeholder="Enter your height in centimeters"
            value={userData.height || ''}
            onChange={(e) => handleHeightChange(e.target.value)}
            className="pl-10 border-health-300 focus:border-health-500 focus:ring-health-500"
            min="50"
            max="300"
            step="0.1"
          />
          <Ruler className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-health-500" />
        </div>
        <p className="text-xs text-health-600">
          Example: 175 cm = 5'9"
        </p>
      </div>

      {/* Weight Input */}
      <div className="space-y-3">
        <Label htmlFor="weight" className="text-health-700 font-medium">Current Weight (kg)</Label>
        <div className="relative">
          <Input
            id="weight"
            type="number"
            placeholder="Enter your current weight in kilograms"
            value={userData.weight || ''}
            onChange={(e) => handleWeightChange(e.target.value)}
            className="pl-10 border-health-300 focus:border-health-500 focus:ring-health-500"
            min="20"
            max="500"
            step="0.1"
          />
          <Weight className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-health-500" />
        </div>
        <p className="text-xs text-health-600">
          Example: 70 kg = 154 lbs
        </p>
      </div>

      {/* BMI Preview */}
      {userData.height > 0 && userData.weight > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-health-100 rounded-lg"
        >
          <h4 className="font-medium text-health-800 mb-2">Your BMI Preview</h4>
          <div className="flex items-center space-x-4">
            <div className="text-2xl font-bold text-health-600">
              {(userData.weight / Math.pow(userData.height / 100, 2)).toFixed(1)}
            </div>
            <div className="text-sm text-health-600">
              {(() => {
                const bmi = userData.weight / Math.pow(userData.height / 100, 2);
                if (bmi < 18.5) return "Underweight";
                if (bmi < 25) return "Normal weight";
                if (bmi < 30) return "Overweight";
                return "Obese";
              })()}
            </div>
          </div>
        </motion.div>
      )}

      {/* Service-specific tips */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="p-4 bg-blue-50 rounded-lg border border-blue-200"
      >
        <h4 className="font-medium text-blue-800 mb-2">
          {service === 'muscle-gain' && "💪 Building muscle requires precision"}
          {service === 'fat-loss' && "🎯 Fat loss success starts with accurate data"}
          {service === 'weight-gain' && "📈 Healthy weight gain needs careful planning"}
          {service === 'performance' && "🚀 Athletic performance demands optimal nutrition"}
        </h4>
        <p className="text-sm text-blue-700">
          Accurate body measurements help us calculate your exact caloric and nutritional needs for optimal results.
        </p>
      </motion.div>
    </div>
  );
}