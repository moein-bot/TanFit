"use client";

import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User, Ruler, Weight, Target, Activity } from 'lucide-react';
import { UserData } from '@/app/questionnaire/[service]/page';

interface CharacterVisualizationProps {
  userData: UserData;
}

export function CharacterVisualization({ userData }: CharacterVisualizationProps) {
  console.log("CharacterVisualization rendered with userData:", userData);

  const getBMI = () => {
    if (userData.height > 0 && userData.weight > 0) {
      return (userData.weight / Math.pow(userData.height / 100, 2)).toFixed(1);
    }
    return null;
  };

  const getBMICategory = () => {
    const bmi = getBMI();
    if (!bmi) return null;
    const bmiValue = parseFloat(bmi);
    if (bmiValue < 18.5) return { label: "Underweight", color: "text-blue-600" };
    if (bmiValue < 25) return { label: "Normal", color: "text-health-600" };
    if (bmiValue < 30) return { label: "Overweight", color: "text-yellow-600" };
    return { label: "Obese", color: "text-red-600" };
  };

  const getCharacterStyle = () => {
    let baseStyle = "transition-all duration-500 ease-in-out";
    let bodyType = "";
    
    // Determine body type based on BMI and gender
    const bmi = getBMI();
    if (bmi) {
      const bmiValue = parseFloat(bmi);
      if (bmiValue < 18.5) bodyType = "slim";
      else if (bmiValue < 25) bodyType = "normal";
      else if (bmiValue < 30) bodyType = "stocky";
      else bodyType = "heavy";
    }

    return { baseStyle, bodyType };
  };

  const getAgeGroup = () => {
    if (userData.age === 0) return "adult";
    if (userData.age < 25) return "young";
    if (userData.age < 45) return "adult";
    if (userData.age < 65) return "middle";
    return "senior";
  };

  return (
    <Card className="h-full organic-card">
      <CardHeader>
        <CardTitle className="text-health-800 flex items-center space-x-2">
          <User className="w-5 h-5" />
          <span>Your Profile</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Character Avatar */}
        <div className="flex justify-center">
          <motion.div
            key={`${userData.gender}-${userData.age}-${getBMI()}`}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            {/* Character representation */}
            <div className={`
              w-32 h-40 mx-auto flex flex-col items-center justify-end
              ${getCharacterStyle().baseStyle}
            `}>
              {/* Head */}
              <motion.div
                animate={{
                  scale: userData.age > 50 ? [1, 1.02, 1] : [1, 1.01, 1]
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className={`
                  w-12 h-12 rounded-full mb-2
                  ${userData.gender === 'female' ? 'bg-gradient-to-br from-pink-200 to-pink-300' : 'bg-gradient-to-br from-blue-200 to-blue-300'}
                  border-2 border-white shadow-md
                  flex items-center justify-center text-lg
                `}
              >
                {userData.gender === 'female' ? '👩' : userData.gender === 'male' ? '👨' : '👤'}
              </motion.div>
              
              {/* Body */}
              <motion.div
                animate={{
                  scaleY: userData.height > 180 ? [1, 1.02, 1] : userData.height < 160 ? [1, 0.98, 1] : [1, 1.01, 1]
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className={`
                  w-16 h-20 rounded-lg shadow-md
                  ${userData.gender === 'female' ? 'bg-gradient-to-b from-pink-300 to-pink-400' : 'bg-gradient-to-b from-blue-300 to-blue-400'}
                  ${(() => {
                    const bmi = getBMI();
                    if (!bmi) return "";
                    const bmiValue = parseFloat(bmi);
                    if (bmiValue < 18.5) return "w-14";
                    if (bmiValue < 25) return "w-16";
                    if (bmiValue < 30) return "w-18";
                    return "w-20";
                  })()}
                `}
              />
            </div>
          </motion.div>
        </div>

        {/* Basic Info Display */}
        <div className="space-y-3">
          {userData.gender && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between"
            >
              <span className="text-health-600 flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span>Gender</span>
              </span>
              <Badge variant="secondary" className="bg-health-100 text-health-800">
                {userData.gender === 'male' ? 'Male' : 'Female'}
              </Badge>
            </motion.div>
          )}

          {userData.age > 0 && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="flex items-center justify-between"
            >
              <span className="text-health-600">Age</span>
              <Badge variant="secondary" className="bg-health-100 text-health-800">
                {userData.age} years
              </Badge>
            </motion.div>
          )}

          {userData.height > 0 && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="flex items-center justify-between"
            >
              <span className="text-health-600 flex items-center space-x-2">
                <Ruler className="w-4 h-4" />
                <span>Height</span>
              </span>
              <Badge variant="secondary" className="bg-health-100 text-health-800">
                {userData.height} cm
              </Badge>
            </motion.div>
          )}

          {userData.weight > 0 && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="flex items-center justify-between"
            >
              <span className="text-health-600 flex items-center space-x-2">
                <Weight className="w-4 h-4" />
                <span>Weight</span>
              </span>
              <Badge variant="secondary" className="bg-health-100 text-health-800">
                {userData.weight} kg
              </Badge>
            </motion.div>
          )}
        </div>

        {/* BMI Display */}
        {getBMI() && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="p-3 bg-health-50 rounded-lg border border-health-200"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-health-700 font-medium">BMI</span>
              <span className="text-2xl font-bold text-health-800">{getBMI()}</span>
            </div>
            {getBMICategory() && (
              <div className={`text-sm font-medium ${getBMICategory()?.color}`}>
                {getBMICategory()?.label}
              </div>
            )}
          </motion.div>
        )}

        {/* Goals Display */}
        {userData.primaryGoal && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="space-y-2"
          >
            <div className="flex items-center space-x-2 text-health-700 font-medium">
              <Target className="w-4 h-4" />
              <span>Current Goal</span>
            </div>
            <Badge className="bg-health-500 text-white">
              {userData.primaryGoal.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase())}
            </Badge>
          </motion.div>
        )}

        {/* Activity Level */}
        {userData.activityLevel && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="space-y-2"
          >
            <div className="flex items-center space-x-2 text-health-700 font-medium">
              <Activity className="w-4 h-4" />
              <span>Activity Level</span>
            </div>
            <Badge variant="outline" className="border-health-300 text-health-700">
              {userData.activityLevel.replace('-', ' ').replace(/\b\w/g, c => c.toUpperCase())}
            </Badge>
          </motion.div>
        )}

        {/* Sports */}
        {userData.sports.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="space-y-2"
          >
            <div className="text-health-700 font-medium text-sm">Sports & Activities</div>
            <div className="flex flex-wrap gap-1">
              {userData.sports.slice(0, 3).map((sport, index) => (
                <Badge key={sport} variant="outline" className="text-xs border-health-200 text-health-600">
                  {sport}
                </Badge>
              ))}
              {userData.sports.length > 3 && (
                <Badge variant="outline" className="text-xs border-health-200 text-health-600">
                  +{userData.sports.length - 3} more
                </Badge>
              )}
            </div>
          </motion.div>
        )}

        {/* Progress Animation */}
        {userData.height > 0 && userData.weight > 0 && userData.primaryGoal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="w-8 h-8 mx-auto mb-2 rounded-full bg-gradient-to-r from-health-400 to-health-600 flex items-center justify-center"
            >
              <span className="text-white text-sm">🎯</span>
            </motion.div>
            <p className="text-xs text-health-600">Building your perfect nutrition plan...</p>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}