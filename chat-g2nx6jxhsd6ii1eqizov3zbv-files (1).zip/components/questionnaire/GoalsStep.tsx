"use client";

import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Target, Calendar, TrendingUp, Award } from 'lucide-react';
import { UserData } from '@/app/questionnaire/[service]/page';

interface GoalsStepProps {
  userData: UserData;
  updateUserData: (data: Partial<UserData>) => void;
  service: string;
}

const goalOptions = {
  'muscle-gain': [
    { value: 'lean-muscle', label: 'Build Lean Muscle', icon: '💪' },
    { value: 'bulk', label: 'Gain Mass Quickly', icon: '🏋️' },
    { value: 'strength', label: 'Increase Strength', icon: '💯' },
    { value: 'maintain-build', label: 'Maintain & Build', icon: '⚖️' }
  ],
  'fat-loss': [
    { value: 'fat-loss', label: 'Lose Body Fat', icon: '🔥' },
    { value: 'weight-loss', label: 'Lose Weight', icon: '📉' },
    { value: 'tone', label: 'Tone & Define', icon: '✨' },
    { value: 'cut', label: 'Cut for Competition', icon: '🏆' }
  ],
  'weight-gain': [
    { value: 'healthy-gain', label: 'Healthy Weight Gain', icon: '📈' },
    { value: 'muscle-weight', label: 'Gain Muscle Weight', icon: '💪' },
    { value: 'recovery', label: 'Recovery Weight Gain', icon: '❤️' },
    { value: 'athletic-gain', label: 'Athletic Weight Gain', icon: '🏃' }
  ],
  'performance': [
    { value: 'endurance', label: 'Improve Endurance', icon: '🏃' },
    { value: 'power', label: 'Increase Power', icon: '⚡' },
    { value: 'recovery', label: 'Enhance Recovery', icon: '🔄' },
    { value: 'competition', label: 'Competition Prep', icon: '🏆' }
  ]
};

const timelines = [
  { value: '1-month', label: '1 Month', description: 'Quick results' },
  { value: '3-months', label: '3 Months', description: 'Moderate timeline' },
  { value: '6-months', label: '6 Months', description: 'Sustainable approach' },
  { value: '12-months', label: '1 Year+', description: 'Long-term transformation' }
];

const experienceLevels = [
  { value: 'beginner', label: 'Beginner', description: 'New to fitness and nutrition' },
  { value: 'intermediate', label: 'Intermediate', description: '1-3 years of experience' },
  { value: 'advanced', label: 'Advanced', description: '3+ years of experience' },
  { value: 'expert', label: 'Expert', description: 'Professional level' }
];

export function GoalsStep({ userData, updateUserData, service }: GoalsStepProps) {
  console.log("GoalsStep rendered for service:", service, "with userData:", userData);

  const currentGoalOptions = goalOptions[service as keyof typeof goalOptions] || goalOptions['muscle-gain'];

  const handleGoalChange = (value: string) => {
    console.log("Primary goal changed to:", value);
    updateUserData({ primaryGoal: value });
  };

  const handleTimelineChange = (value: string) => {
    console.log("Timeline changed to:", value);
    updateUserData({ timeline: value });
  };

  const handleExperienceChange = (value: string) => {
    console.log("Experience level changed to:", value);
    updateUserData({ experience: value });
  };

  const handleTargetWeightChange = (value: string) => {
    const targetWeight = parseFloat(value) || undefined;
    console.log("Target weight changed to:", targetWeight);
    updateUserData({ targetWeight });
  };

  return (
    <div className="space-y-6">
      {/* Primary Goal */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium flex items-center space-x-2">
          <Target className="w-4 h-4" />
          <span>What's your primary goal?</span>
        </Label>
        <RadioGroup
          value={userData.primaryGoal}
          onValueChange={handleGoalChange}
          className="grid grid-cols-1 md:grid-cols-2 gap-3"
        >
          {currentGoalOptions.map((goal) => (
            <motion.div
              key={goal.value}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Card className={`cursor-pointer transition-all duration-200 ${
                userData.primaryGoal === goal.value ? 'ring-2 ring-health-400 bg-health-50' : 'hover:shadow-md'
              }`}>
                <CardContent className="flex items-center space-x-3 p-4">
                  <RadioGroupItem value={goal.value} id={goal.value} />
                  <Label htmlFor={goal.value} className="cursor-pointer flex items-center space-x-2 flex-1">
                    <span className="text-xl">{goal.icon}</span>
                    <span>{goal.label}</span>
                  </Label>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </RadioGroup>
      </div>

      {/* Target Weight (conditional) */}
      {(service === 'fat-loss' || service === 'weight-gain') && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="space-y-3"
        >
          <Label htmlFor="targetWeight" className="text-health-700 font-medium flex items-center space-x-2">
            <TrendingUp className="w-4 h-4" />
            <span>Target Weight (kg) - Optional</span>
          </Label>
          <Input
            id="targetWeight"
            type="number"
            placeholder="Enter your target weight"
            value={userData.targetWeight || ''}
            onChange={(e) => handleTargetWeightChange(e.target.value)}
            className="border-health-300 focus:border-health-500 focus:ring-health-500"
            min="20"
            max="500"
            step="0.1"
          />
          <p className="text-xs text-health-600">
            This helps us create a more specific plan for your journey
          </p>
        </motion.div>
      )}

      {/* Timeline */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium flex items-center space-x-2">
          <Calendar className="w-4 h-4" />
          <span>What's your timeline?</span>
        </Label>
        <Select value={userData.timeline} onValueChange={handleTimelineChange}>
          <SelectTrigger className="border-health-300 focus:border-health-500 focus:ring-health-500">
            <SelectValue placeholder="Choose your timeline" />
          </SelectTrigger>
          <SelectContent>
            {timelines.map((timeline) => (
              <SelectItem key={timeline.value} value={timeline.value}>
                <div className="flex flex-col">
                  <span className="font-medium">{timeline.label}</span>
                  <span className="text-xs text-health-600">{timeline.description}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Experience Level */}
      <div className="space-y-3">
        <Label className="text-health-700 font-medium flex items-center space-x-2">
          <Award className="w-4 h-4" />
          <span>What's your experience level?</span>
        </Label>
        <RadioGroup
          value={userData.experience}
          onValueChange={handleExperienceChange}
          className="grid grid-cols-1 md:grid-cols-2 gap-3"
        >
          {experienceLevels.map((level) => (
            <motion.div
              key={level.value}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Card className={`cursor-pointer transition-all duration-200 ${
                userData.experience === level.value ? 'ring-2 ring-health-400 bg-health-50' : 'hover:shadow-md'
              }`}>
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <RadioGroupItem value={level.value} id={level.value} className="mt-1" />
                    <Label htmlFor={level.value} className="cursor-pointer flex-1">
                      <div className="font-medium text-health-800">{level.label}</div>
                      <div className="text-sm text-health-600">{level.description}</div>
                    </Label>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </RadioGroup>
      </div>

      {/* Service-specific motivation */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="p-4 bg-health-100 rounded-lg"
      >
        <h4 className="font-medium text-health-800 mb-2">
          {service === 'muscle-gain' && "🎯 Muscle Building Success Tips"}
          {service === 'fat-loss' && "🔥 Fat Loss Strategy"}
          {service === 'weight-gain' && "📈 Healthy Weight Gain Approach"}
          {service === 'performance' && "🚀 Performance Optimization"}
        </h4>
        <p className="text-sm text-health-700">
          {service === 'muscle-gain' && "Building muscle requires consistent nutrition with adequate protein and calories. We'll calculate your exact needs based on your goals and timeline."}
          {service === 'fat-loss' && "Sustainable fat loss combines a moderate caloric deficit with proper macronutrient distribution to preserve muscle mass while losing fat."}
          {service === 'weight-gain' && "Healthy weight gain focuses on nutrient-dense foods and controlled caloric surplus to build lean mass without excessive fat gain."}
          {service === 'performance' && "Athletic performance nutrition emphasizes timing, recovery, and sport-specific nutritional strategies for optimal results."}
        </p>
      </motion.div>
    </div>
  );
}